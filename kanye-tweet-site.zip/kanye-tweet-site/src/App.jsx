
import KanyeTweetArchive from './KanyeTweetArchive'
export default function App() {
  return <KanyeTweetArchive />;
}
